-- Cannon ball
-- There are two types of canonn balls: normal and bomb

local physics = require('physics')
local sounds = require('lib.sounds')

local _M = {}

local newPuff = require('classes.puff').newPuff

function _M.newBall(params)
	local ball = display.newImageRect( 'images/ammo/' .. params.type .. '.png', 48, 48)
	ball.x, ball.y = params.x, params.y
	-- While the ball rests near the cannon, it's static
	physics.addBody(ball, 'static', {density = 2, friction = 0.5, bounce = 0.4, radius = ball.width / 2})
	ball.isBullet = true -- More accurate collision detection
	ball.angularDamping = 3 -- Prevent the ball from rolling for too long
	ball.type = params.type
	ball.name = params.name
	params.m:addObject("collision", ball)
	ball.map = params.m
	function ball:launch(dir, force)
		dir = math.rad(dir) -- We need the direction angle in radians for calculations below
		ball.bodyType = 'dynamic' -- Change to dynamic so it can move
		ball:applyLinearImpulse(force * math.cos(dir), force * math.sin(dir), ball.x, ball.y)
		ball.isLaunched = true
	end

	function ball:explode()
		sounds.play('explosion')
		local radius = 192 -- Explosion radius, all objects touching this area will be affected by the explosion
		local area = display.newCircle(params.g, self.x, self.y, radius)
		area.name = "explode"
		area.isVisible = false
		physics.addBody(area, 'dynamic', {isSensor = true, radius = radius})
		self.map:addObject("collision",area)
		
		-- The trick is to create a large circle, grab all collisions and destroy it
		local affected = {} -- Keep affected bodies here
		function area:collision(event)
			if event.phase == 'began' then
				if not affected[event.other] then
					affected[event.other] = true
					local x, y = event.other.x - self.x, event.other.y - self.y
					local dir = math.atan2(y, x) * 180 / math.pi
					local force = (radius - math.sqrt(x ^ 2 + y ^ 2)) * 4 -- Reduce the force with the distance from the explosion
					-- If an object touches the explosion, the force will be at least this big
					if force < 20 then
						force = 20
					end
					event.other:applyLinearImpulse(force * math.cos(dir), force * math.sin(dir), event.other.x, event.other.y)
				end
			end
		end
		area:addEventListener('collision')
		timer.performWithDelay(1, function()
			self.map:removeLayerObject("collision", area.name)
		end)
		
		self.map:removeLayerObject("collision", self.name)
	end

	function ball:destroy()
		-- The ball can either be destroyed as a normal one or as bomb with an explosions
		newPuff({g = params.g, x = self.x, y = self.y, isExplosion = self.type == 'bomb'})
		self.map:trackEnabled(false)
		self.map:setCameraFocus(nil)			
		if self.type == 'bomb' then
			self:explode()
		else
			sounds.play('ball_destroy')
			self.map:removeLayerObject("collision", self.name)
			--print ("ball destroy")
		end
	end

	return ball
end

return _M
