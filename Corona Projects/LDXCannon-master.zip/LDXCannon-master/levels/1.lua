return {
	map = 1,
	cannon = {mapX = 4, mapY = 5},
	ammo = {'normal', 'normal'},
	bugs = {
		{x = 1289, y = 358}
	},
	blocks = {
		{material = 'wood', name = 'rectangle5', x = 1230, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1343, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle4', x = 1287, y = 255, rotation = 0},
		{material = 'stone', name = 'rectangle1', x = 1192, y = 366, rotation = 0},
		{material = 'stone', name = 'rectangle1', x = 1379, y = 366, rotation = 0},
		{material = 'wood', name = 'rectangle2', x = 1424, y = 347, rotation = 38},
		{material = 'wood', name = 'rectangle2', x = 1146, y = 348, rotation = 321}
	},
}
