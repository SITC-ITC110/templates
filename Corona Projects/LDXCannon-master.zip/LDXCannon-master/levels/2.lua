return {
	map = 2,
	cannon = {mapX = 4, mapY = 5},
	ammo = {'normal', 'normal'},
	bugs = {
		{x = 1289, y = 358},
		{x = 1286, y = 212}
	},
	blocks = {
		{material = 'wood', name = 'rectangle5', x = 1229, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1342, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle4', x = 1286, y = 255, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1164, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1163, y = 218, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1402, y = 328, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1401, y = 218, rotation = 0},
		{material = 'wood', name = 'rectangle4', x = 1163, y = 145, rotation = 0},
		{material = 'wood', name = 'rectangle4', x = 1401, y = 145, rotation = 0}
	},
}
