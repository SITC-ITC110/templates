return {
	map = 2,
	cannon = {mapX = 6, mapY = 4},
	ammo = {'normal', 'normal', 'normal', 'normal', 'normal', 'normal', 'normal'},
	bugs = {
		{x = 1596, y = 230},
		{x = 2302, y = 166},
		{x = 2947, y = 2}
	},
	blocks = {
		{material = 'wood', name = 'rectangle5', x = 1500, y = 200, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 1688, y = 200, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 2226, y = 136, rotation = 0},
		{material = 'wood', name = 'rectangle5', x = 2381, y = 136, rotation = 0},
		{material = 'wood', name = 'rectangle4', x = 2941, y = 46, rotation = 0}
	},
}
