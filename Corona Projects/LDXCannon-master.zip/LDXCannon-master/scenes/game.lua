-- Game Scene
-- All actual gameplay happens here.
-- This scene loads and shows many various little pieces from the rest of the project and combines them together.

local composer = require('composer') -- Scene management
local physics = require('physics') -- Box2D physics
local widget = require('widget') -- Buttons
local controller = require('lib.controller') -- Gamepad support
local databox = require('lib.databox') -- Persistant storage, track level completion and settings
local eachframe = require('lib.eachframe') -- enterFrame manager
local sounds = require('lib.sounds') -- Music and sounds manager
local relayout = require('lib.relayout') -- Repositions elements on screen on window resize
local newPuff = require('classes.puff').newPuff
require("lib.LD_LoaderX") -- ldx loader

physics.start()
physics.setGravity(0, 20) -- Default gravity is too boring

local scene = composer.newScene()

-- LEVEL EDITOR
-- Uncomment to enable level editing features
--require('classes.level_editor').enableLevelEditor(scene)

local newCannon = require('classes.cannon').newCannon -- The ultimate weapon
local newBug = require('classes.bug').newBug -- Enemies to kill, debug powers
local newBlock = require('classes.block').newBlock -- Building blocks for the levels
local newSidebar = require('classes.sidebar').newSidebar -- Settings and pause sidebar
local newEndLevelPopup = require('classes.end_level_popup').newEndLevelPopup -- Win/Lose dialog windows
local bugLabel = nil 
_W, _H = display.actualContentWidth, display.actualContentHeight
_CX, _CY = _W / 2, _H / 2

function scene:create(event)
	local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

	local group = self.view
	self.levelId = event.params
	local background = display.newRect(group, _CX, _CY, _W,  _H)
	background.fill = {
	    type = 'gradient',
	    color1 = {0.2, 0.45, 0.8},
	    color2 = {0.7, 0.8, 1}
	}
	relayout.add(background)

	-- The central element - LDX map
	self.map = LD_Loader:new()
	-- load level 
	self.map:loadLevel("Level".. string.format("%02d",self.levelId,group) )
	self.map:setCameraBounds(_CX,-_CY/2 ,self.map.level.canvasWidth - _CX,self.map.level.canvasHeight - _CY )
	local GUIGroup = self.map:getLayer("GUI").view 
	-- -- Bugs, blocks and balls are inserted into self.map.physicsGroup
	self.bugs = {}
	self.bugs = self.map:layerObjectsWithClass("collision","bug")
	for i = 1, #self.bugs do
		local bug = self.bugs[i].view
		bug.isAlive = true
		bug.map = self.map 
		function bug:destroy()
			sounds.play('bug')
			self.isAlive = false
			newPuff({g = bug.parent, x = self.x, y = self.y})
			timer.performWithDelay(1, function()
				self.map:removeLayerObject("collision",self.name)
				--self:removeSelf()
			end)
		end

		function bug:postCollision(event)
			-- Increase this value to make the bugs stronger
			if event.force > 30 and self.isAlive then
				self:destroy()
			end
		end
		bug:addEventListener('postCollision')		
	end

	self.blocks = {}
	self.blocks = self.map:layerObjectsWithClass("collision","block")
	for i = 1, #self.blocks do
		local block = self.blocks[i]
		block.view.forceThreshold = 75
		local material = block.property["material"]
		-- Increase density and strength for stone blocks
		if material == 'stone' then
			block.view.forceThreshold = 150
		end
		block.view.angularDamping = 3 -- Prevent from rolling for too long
		block.view.isAlive = true
		block.view.map = self.map 
		
		function block.view:destroy()
			sounds.play('poof')
			self.isAlive = false
			newPuff({g = self.parent, x = self.x, y = self.y})
			timer.performWithDelay(1, function()
				self.map:removeLayerObject("collision",self.name)
			end)
		end

		function block.view:postCollision(event)
			if self.isAlive then
				-- Small impact detection just to play a sound
				if event.force > 20 then
					local vx, vy = event.other:getLinearVelocity()
					if vx + vy > 4 then
						sounds.play('impact')
					end
				end
				if event.force >= self.forceThreshold then
					self:destroy()
				end
			end
		end
		block.view:addEventListener('postCollision')
	end
	
	-- -- Handle touch events, wait a little for camera to slide
	self:createTouchRect({delay = 2000})
	self.cannon = newCannon({map = self.map, level = self.level})

	-- Preload End Level Popup and Sidebar
	self.endLevelPopup = newEndLevelPopup({g = GUIGroup, levelId = self.levelId})
	self.endLevelPopup:toFront() -- Put cannon in front of the touchRect
	self.sidebar = newSidebar({g = GUIGroup, levelId = self.levelId, onHide = function()
		self:setIsPaused(false)
		controller.setVisualButtons()
	end})
	self.sidebar:toFront()
	
	local levelLabel = display.newText({
		parent = group,
		text = 'Level: ' .. self.levelId,
		x = _W - 16, y = 16,
		font = native.systemFontBold,
		fontSize = 32
	})
	levelLabel.anchorX, levelLabel.anchorY = 1, 0
	relayout.add(levelLabel)
	
	bugLabel = display.newText({
		parent = group,
		text = 'Bugs: ' .. #self.bugs,
		x = _W - 200, y = 16,
		font = native.systemFontBold,
		fontSize = 32
	})
	bugLabel.anchorX, bugLabel.anchorY = 1, 0
	relayout.add(bugLabel)

	local pauseButton = widget.newButton({
		defaultFile = 'images/buttons/pause.png',
		overFile = 'images/buttons/pause-over.png',
		width = 96, height = 105,
		x = 16, y = 16,
		onRelease = function()
			sounds.play('tap')
			self.sidebar:show()
			self:setIsPaused(true)
		end
	})
	pauseButton.anchorX, pauseButton.anchorY = 0, 0
	group:insert(pauseButton)
	relayout.add(pauseButton)

	self.sidebar:toFront()

	controller.setVisualButtons() -- No on-screen buttons, that can be navigated to with a controller

	local function switchMotionAndRotation()
		-- Switch for tvOS, because it has only one touchpad (axis)
		controller.onMotion, controller.onRotation = controller.onRotation, controller.onMotion
	end

	-- Map movement on gamepad left stick
	controller.onMotion = function(name, value)
		local x,y =0,0
		if not self.isPaused then
			self.map:trackEnabled(false)
			if name == 'x' then
				x = -value
			elseif name == 'y' then
				y = value
			end
			self.map:move(x,y)
		end
	end
	-- Cannon control on gamepad right stick
	controller.onRotation = function(name, value)
		if not self.isPaused then
			if self.cannon.ball and not self.cannon.ball.isLaunched then
				self.map:setCameraFocus(self.cannon)
			end
			if math.abs(value) >= 0.08 or math.abs(value) < 0.02 then
				if name == 'x' then
					self.cannon.radiusIncrement = -value -- Invert x axis to resemble a slingshot
				elseif name == 'y' then
					self.cannon.rotationIncrement = value
				end
			end
		end
	end
	-- -- Other gamepad and keyboard buttons
	controller.onKey = function(keyName, keyType)
		if not self.isPaused then
			if keyType == 'action' then
				if keyName == 'buttonA' then
					switchMotionAndRotation()
				else
					self.cannon:engageForce()
				end
			elseif keyType == 'pause' then
				pauseButton._view._onRelease()
			end
		end
	end

	-- On tvOS default to cannon control with the remote
	if system.getInfo('platformName') == 'tvOS' then
		switchMotionAndRotation()
	end
end

function scene:show(event)
	if event.phase == 'did' then
		function onScrollFinished2() 
			print ("scroll2 finished")
		end 
		function slideFinish()
			timer.performWithDelay(400, function () return self.map:slideCameraToPosition(0, 0, 800, easing.inOutQuad, onScrollFinished2) end )			
		end 
		
		timer.performWithDelay(400, function () return self.map:slideCameraToPosition(self.map.level.canvasWidth - display.contentWidth, 0, 1000, easing.inOutQuad,slideFinish) end) -- Slide it back to the cannon
		eachframe.add(self) -- Each frame self:eachFrame() is called

		-- Only check once in a while for level end
		self.endLevelCheckTimer = timer.performWithDelay(2300, function()
			self:endLevelCheck()
		end, 0)

		-- Show help image once
		if not databox.isHelpShown then
			timer.performWithDelay(2500, function()
				self.sidebar:show()
				self:setIsPaused(true)
			end)
		end

		sounds.playStream('game_music')
	end
end

-- Check for bugs and blocks being dead or outside the borders
function scene:eachFrame()
	local tables = {self.bugs, self.blocks}
	for i = 1, #tables do
		local t = tables[i]
		for j = #t, 1, -1 do
			local b = t[j]
			if b.view.isAlive then
				if b.view.x < 0 or b.view.x > self.map.level.canvasWidth or b.view.y > self.map.level.canvasHeight then
					b.view:destroy()
				end
			else
				table.remove(t, j)
			end
		end
	end

	-- move clouds
	local l = self.map:getLayer("parallax3")
	--l.x = self.camera.x - self.camera.x * l.ratio
	local speed = tonumber(l.xSpeed) or 0
	if speed ~= 0 then
		for j = 1, #l.objects do
			local object = l.objects[j].view
			
			object.x = object.x + speed
			if object.x < -object.width then
				object.x = object.x + self.map.level.canvasWidth + object.width
			end
		end
	end
	
end

function scene:setIsPaused(isPaused)
	self.isPaused = isPaused
	self.cannon.isPaused = self.isPaused -- Pause adding trajectory points
	if self.isPaused then
		physics.pause()
	else
		physics.start()
	end
end

-- Check if the player won or lost
function scene:endLevelCheck()
	
	if not self.isPaused then
		if #self.bugs == 0 then
			sounds.play('win')
			self.map:trackEnabled(false)
			self.map:setCameraFocus(nil)
			self:setIsPaused(true)
			self.endLevelPopup:show({isWin = true})
			timer.cancel(self.endLevelCheckTimer)
			self.endLevelCheckTimer = nil
			databox['level' .. self.levelId] = true -- Save level completion
		elseif self.cannon:getAmmoCount() == 0 then
			sounds.play('lose')
			self.map:trackEnabled(false)
			self.map:setCameraFocus(nil)
			self:setIsPaused(true)
			self.endLevelPopup:show({isWin = false})
			timer.cancel(self.endLevelCheckTimer)
			self.endLevelCheckTimer = nil
		end
		bugLabel.text = 'Bugs: ' .. #self.bugs
	end
end

-- Touch to pan the map
function scene:createTouchRect(params)
	local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

	local group = self.view
	local map = self.map
	local delay = params.delay or 1
	local touchRect = display.newRect(group, _CX, _CY, _W, _H)
	touchRect.isVisible = false
	relayout.add(touchRect)

	function touchRect:touch(event)
		if (map.level.isTracking) then 
			return
		end 
		if event.phase == 'began' then
			display.getCurrentStage():setFocus(self, event.id)
			self.isFocused = true
			self.xStart, self.yStart = event.x, event.y
		elseif self.isFocused then
			if event.phase == 'moved' then
				map:trackEnabled(false)
				map:move((self.xStart - event.x), (self.yStart - event.y) , true )
				self.xStart, self.yStart = event.x, event.y
			else
				display.getCurrentStage():setFocus(self, nil)
				self.isFocused = false
			end
		end
		return true
	end
	touchRect:addEventListener('touch')

	timer.performWithDelay(delay, function()
		touchRect.isHitTestable = true
	end)
end

-- Device's back button action
function scene:gotoPreviousScene()
	native.showAlert('Corona Cannon', 'Are you sure you want to exit this level?', {'Yes', 'Cancel'}, function(event)
		if event.action == 'clicked' and event.index == 1 then
			composer.gotoScene('scenes.menu', {time = 500, effect = 'slideRight'})
		end
	end)
end

-- Clean up
function scene:hide(event)
	if event.phase == 'will' then
		eachframe.remove(self)
		controller.onMotion = nil
		controller.onRotation = nil
		controller.onKey = nil
		if self.endLevelCheckTimer then
			timer.cancel(self.endLevelCheckTimer)
		end
		self.map:removeLevel()
	elseif event.phase == 'did' then
		physics.stop()
	end
end

scene:addEventListener('create')
scene:addEventListener('show')
scene:addEventListener('hide')

return scene
